from langchain_core.prompts import ChatPromptTemplate
from langchain_openai import ChatOpenAI
from langchain_core.runnables import RunnablePassthrough

def get_reservation_info(reservation_id):
    """Simula una consulta a base de datos"""
    if reservation_id == "HMS8FTTQN4":
        return """
        Check-in: 2024-11-23 16:00:00
        Check-out: 2024-11-28 11:00:00
        Huéspedes totales: 5
        Estado de la reserva: pendiente
        Huéspedes registrados: 0 de 5
        Formulario policía: pendiente
        """
    return "Reserva no encontrada"

def create_reservation_chain():
    # 1. Crear un modelo
    llm = ChatOpenAI()
    
    # 2. Crear un prompt template
    prompt = ChatPromptTemplate.from_messages([
        ("system", """Eres un asistente que ayuda a consultar información de reservas.
        Cuando te den un número de reserva, muestra un resumen amigable de la información.
        
        Ejemplo de respuesta:
        "La reserva HMS8FTTQN4 tiene check-in el 23 de noviembre a las 16:00 y check-out
        el 28 de noviembre a las 11:00. Hay 5 huéspedes registrados."
        """),
        ("human", "Aquí está la información de la reserva: {Informacion}\nNúmero de reserva: {Reserva}")
    ])
    
    # 3. Crear la chain con el paso de obtener información
    get_info = RunnablePassthrough.assign(
        Informacion=lambda x: get_reservation_info(x["Reserva"])
    )
    
    # 4. Retornar la chain completa
    return get_info | prompt | llm

def main():
    # Crear la chain
    chain = create_reservation_chain()
    
    # Ejemplo de datos
    data = {
        "Reserva": "HMS8FTTQN4"
    }
    
    # Procesar la reserva
    response = chain.invoke(data)
    print(f"\nRespuesta: {response.content}")

if __name__ == "__main__":
    main()