from flask import Flask, render_template, jsonify, request, session
from importlib.util import spec_from_file_location, module_from_spec
import os
from pathlib import Path
from dotenv import load_dotenv
import glob

# Cargar variables de entorno
root_env = Path(__file__).parent.parent / '.env'
load_dotenv(root_env)

app = Flask(__name__)
app.secret_key = os.urandom(24)  # Necesario para las sesiones

# Diccionario para almacenar las chains por sesión
chains = {}

def get_available_scripts():
    """Obtiene lista de scripts Python en el directorio actual"""
    scripts = glob.glob('*.py')
    # Excluir app.py y archivos que empiecen con _
    return [s for s in scripts if s != 'app.py' and not s.startswith('_')]

def load_script(script_name):
    script_path = Path(__file__).parent / script_name
    if not script_path.exists():
        return None
    
    try:
        spec = spec_from_file_location(script_name, script_path)
        module = module_from_spec(spec)
        spec.loader.exec_module(module)
        return module
    except Exception as e:
        print(f"Error loading script {script_name}: {e}")
        return None

@app.route('/')
def home():
    scripts = get_available_scripts()
    return render_template('index.html', scripts=scripts)

@app.route('/api/scripts')
def list_scripts():
    scripts = get_available_scripts()
    return jsonify(scripts)

@app.route('/api/reservation/<reservation_id>')
def get_reservation(reservation_id):
    script_name = request.args.get('script', '03_db_reservation_chain.py')
    
    # Cargar el script
    script = load_script(script_name)
    if not script:
        return jsonify({'error': f'Error loading {script_name}'}), 500
    
    try:
        # Crear la chain y procesar la reserva
        chain = script.create_reservation_chain()
        response = chain.invoke({
            "Reserva": reservation_id
        })
        
        return jsonify({
            'summary': response.content,
            'reservation': {'id': reservation_id}
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/chat', methods=['POST'])
def chat():
    message = request.json.get('message')
    script_name = request.json.get('script', '04_conversation_chain.py')
    
    if not message:
        return jsonify({'error': 'No message provided'}), 400
    
    # Cargar el script de conversación
    script = load_script(script_name)
    if not script:
        return jsonify({'error': f'Error loading {script_name}'}), 500
    
    try:
        # Obtener o crear la chain para esta sesión
        session_id = session.get('session_id')
        if not session_id:
            session_id = os.urandom(16).hex()
            session['session_id'] = session_id
        
        chain_key = f"{script_name}_{session_id}"
        if chain_key not in chains:
            if script_name == '05_advanced_memory_chain.py':
                vector_store = script.VectorStoreHandler("reservation_history")
                chains[chain_key] = script.create_reservation_chain(vector_store=vector_store)
            else:
                chains[chain_key] = script.create_reservation_chain()
        
        # Procesar el mensaje usando la chain existente
        chain = chains[chain_key]
        response = chain.invoke(message)
        
        # Extraer el contenido del mensaje si es un objeto Message
        if hasattr(response, 'content'):
            response_text = response.content
        else:
            response_text = response
        
        return jsonify({
            'response': response_text,
            'session_id': session_id
        })
    
    except Exception as e:
        return jsonify({'error': f'Error processing message: {str(e)}'}), 500

if __name__ == '__main__':
    app.run(debug=True, port=5001)
