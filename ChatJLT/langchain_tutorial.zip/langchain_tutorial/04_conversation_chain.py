from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_openai import ChatOpenAI
from langchain.memory import ConversationBufferMemory
from langchain_core.messages import HumanMessage, AIMessage
from mysql.connector import Error
from db_connection import get_db_connection
import re

"""
Aquí utilizamos ConversationBufferMemory de langchain.
es muy basica, envía toda la conversación en cada prompt
si queremos algo más complejo:
ConversationSummaryMemory: Resume la conversación para no exceder el contexto
VectorStoreMemory: Usa embeddings y búsqueda semántica
ConversationKGMemory: Construye un grafo de conocimiento
ConversationEntityMemory: Se centra en recordar entidades específicas
"""


def get_reservation_info(reservation_id):
    conn = get_db_connection()
    if not conn:
        return "Error: No se pudo conectar a la base de datos"
        
    try:
        cursor = conn.cursor(dictionary=True)
        cursor.execute("""
            SELECT 
                r.id,
                r.check_in,
                r.check_out,
                r.num_guests,
                r.status
            FROM reservation r
            WHERE r.provider_reservation_id = %s
        """, (reservation_id,))
        
        reservation = cursor.fetchone()
        
        if not reservation:
            return None

        cursor.execute("""
            SELECT `key`, `value`
            FROM reservation_extra_data
            WHERE reservation_id = %s
            AND `key` IN ('guests_registered', 'police_form_status')
        """, (reservation['id'],))
        
        extra_data = {}
        for row in cursor.fetchall():
            extra_data[row['key']] = row['value']
        
        return {
            'check_in': reservation['check_in'].isoformat() if reservation['check_in'] else None,
            'check_out': reservation['check_out'].isoformat() if reservation['check_out'] else None,
            'num_guests': reservation['num_guests'],
            'status': reservation['status'],
            'guests_registered': extra_data.get('guests_registered', '0'),
            'police_form_status': extra_data.get('police_form_status', 'pendiente')
        }
        
    except Error as e:
        print(f"Error consultando la reserva: {e}")
        return f"Error: {str(e)}"
    finally:
        cursor.close()
        conn.close()

def create_reservation_chain():
    # 1. Crear un modelo
    llm = ChatOpenAI()
    
    # 2. Crear memoria para la conversación
    memory = ConversationBufferMemory(
        return_messages=True,
        memory_key="chat_history"
    )
    
    # 3. Crear un prompt template
    prompt = ChatPromptTemplate.from_messages([
        ("system", """Eres un asistente amable y eficiente que ayuda a consultar información de reservas.

IMPORTANTE: Antes de solicitar cualquier información, SIEMPRE debes:
1. Revisar el historial completo de la conversación
2. Buscar si ya se mencionó algún número de reserva
3. Si encuentras un número de reserva previo, úsalo sin pedirlo de nuevo
4. Solo pide el número de reserva si no hay ninguno en el historial

Cuando respondas:
1. Si ya tienes un número de reserva (del mensaje actual o del historial), úsalo directamente
2. Si no tienes número de reserva, pídelo amablemente
3. Si el número no es válido, informa del error y pide otro
4. Mantén un tono conversacional y amigable

Ejemplo de comportamiento correcto:
Usuario: "¿A qué hora puedo hacer check-in?"
Asistente: "¿Me podrías proporcionar el número de reserva?"
Usuario: "HMS8FTTQN4"
Asistente: [muestra información del check-in]
Usuario: "¿Y el check-out?"
Asistente: [usa HMS8FTTQN4 del historial y muestra información del check-out sin pedirlo de nuevo]
"""),
        MessagesPlaceholder(variable_name="chat_history"),
        ("human", "{input}")
    ])
    
    # 4. Crear una cadena conversacional
    chain = prompt | llm

    # 5. Función para procesar cada mensaje
    def process_message(message, session_id='default'):
        nonlocal memory  # Usar la memoria creada en el scope superior
        
        # Buscar un posible ID de reserva en el mensaje
        reservation_pattern = r'[A-Z0-9]{6,}'
        potential_ids = re.findall(reservation_pattern, message)
        
        # Si encontramos un ID, intentar obtener la información
        reservation_info = None
        for potential_id in potential_ids:
            info = get_reservation_info(potential_id)
            if info and not isinstance(info, str):  # No es un mensaje de error
                reservation_info = info
                break
        
        if reservation_info:
            # Formatear la información para el LLM
            message = f"""
            He encontrado la reserva {potential_id}:
            Check-in: {reservation_info['check_in']}
            Check-out: {reservation_info['check_out']}
            Huéspedes totales: {reservation_info['num_guests']}
            Estado de la reserva: {reservation_info['status']}
            Huéspedes registrados: {reservation_info['guests_registered']} de {reservation_info['num_guests']}
            Formulario policía: {reservation_info['police_form_status']}
            """
        
        # Invocar la chain con el historial de chat
        response = chain.invoke({
            "input": message,
            "chat_history": memory.chat_memory.messages
        })
        
        # Guardar el intercambio en la memoria
        memory.save_context({"input": message}, {"output": response.content})
        
        return response

    return process_message

def main():
    # Crear la cadena
    chain = create_reservation_chain()
    
    # Ejemplo de conversación
    messages = [
        "Necesito saber si los huéspedes han rellenado el formulario",
        "Es la reserva HMS8FTTQN4",
        "¿Y cuándo es el check-out?",
    ]
    
    print("Iniciando conversación de ejemplo:")
    for message in messages:
        print(f"\nUsuario: {message}")
        response = chain(message)
        print(f"Asistente: {response.content}")

if __name__ == "__main__":
    main()
