from dotenv import load_dotenv
from pathlib import Path
import mysql.connector
from mysql.connector import Error
import os

# Cargar variables de entorno desde el directorio raíz
root_env = Path(__file__).parent.parent / '.env'
load_dotenv(root_env)

def get_required_env(key: str) -> str:
    """
    Obtiene una variable de entorno requerida o lanza un error si no existe
    """
    value = os.getenv(key)
    if value is None:
        raise ValueError(f"Variable de entorno requerida '{key}' no encontrada")
    return value

def get_db_connection():
    """
    Establece una conexión a la base de datos usando variables de entorno.
    Lanza un error si falta alguna variable requerida.
    """
    try:
        # Obtener todas las variables requeridas primero
        host = get_required_env('DB_HOST')
        port = int(get_required_env('DB_PORT'))
        database = get_required_env('DB_DATABASE')
        user = get_required_env('DB_USERNAME')
        password = get_required_env('DB_PASSWORD')
        
        # Intentar la conexión
        connection = mysql.connector.connect(
            host=host,
            port=port,
            database=database,
            user=user,
            password=password
        )
        
        if not connection.is_connected():
            raise Error("No se pudo establecer la conexión con la base de datos")
            
        return connection
        
    except ValueError as e:
        # Error de variable de entorno faltante
        print(f"Error de configuración: {e}")
        return None
    except Error as e:
        # Error de conexión a MySQL
        print(f"Error conectando a MySQL: {e}")
        return None
