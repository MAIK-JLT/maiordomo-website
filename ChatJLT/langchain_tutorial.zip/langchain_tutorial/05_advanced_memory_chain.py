from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_openai import ChatOpenAI, OpenAIEmbeddings
from langchain_core.memory import BaseMemory
from langchain_core.messages import HumanMessage, AIMessage, BaseMessage
from langchain_chroma import Chroma
import chromadb
from mysql.connector import Error
from db_connection import get_db_connection
import re
import json
from datetime import datetime
from typing import Dict, List, Optional, Any, Tuple
import os
from pydantic import BaseModel, Field
from pathlib import Path

# Crear directorio para Chroma si no existe
CHROMA_DIR = Path(__file__).parent / "chroma_db"
CHROMA_DIR.mkdir(exist_ok=True)

class VectorStoreHandler:
    """Manejador de búsqueda semántica usando vectorstore"""
    
    def __init__(self, collection_name: str):
        self.embeddings = OpenAIEmbeddings()
        # Inicializar Chroma solo con lo básico
        self.vectorstore = Chroma(
            collection_name=collection_name,
            embedding_function=self.embeddings,
            persist_directory=str(CHROMA_DIR)
        )
        
    def save_interaction(self, text: str, metadata: Optional[Dict] = None):
        """Guarda una interacción en el vectorstore"""
        if metadata is None:
            metadata = {}
        metadata["timestamp"] = datetime.now().isoformat()
        
        # Solo agregar el documento, la persistencia es automática
        self.vectorstore.add_texts(
            texts=[text],
            metadatas=[metadata]
        )

    def search_similar(self, query: str, k: int = 3) -> List[Tuple[str, float]]:
        """Busca interacciones similares y devuelve textos con scores"""
        results = self.vectorstore.similarity_search_with_score(query, k=k)
        # Filtrar resultados por score (menor score = más similar)
        filtered_results = [
            (doc.page_content, score) 
            for doc, score in results 
            if score < 1.0  # Solo mantener resultados muy similares
        ]
        return filtered_results

class ReservationEntityMemory(BaseMemory):
    """Memoria especializada para manejar entidades de reservas"""
    
    vector_store: VectorStoreHandler = Field(description="Vector store para búsqueda semántica")
    chat_memory: List[BaseMessage] = Field(default_factory=list)
    return_messages: bool = Field(default=True)
    memory_key: str = Field(default="chat_history")
    llm: Any = Field(description="LLM para procesar entidades")
    k: int = Field(default=3, description="Número de entidades similares a recordar")
    
    @property
    def memory_variables(self) -> List[str]:
        """Lista de variables que esta memoria hace disponibles."""
        return [self.memory_key]
        
    def save_context(self, inputs: Dict[str, Any], outputs: Dict[str, str]) -> None:
        """Guarda el contexto tanto en la memoria como en el vectorstore"""
        # Guardar en memoria de mensajes
        if "input" in inputs:
            self.chat_memory.append(HumanMessage(content=inputs["input"]))
        if "output" in outputs:
            self.chat_memory.append(AIMessage(content=outputs["output"]))
            
        # Guardar en vectorstore para búsqueda semántica
        text = f"Input: {inputs.get('input', '')}\nOutput: {outputs.get('output', '')}"
        self.vector_store.save_interaction(text)

    def load_memory_variables(self, inputs: Dict[str, Any]) -> Dict[str, Any]:
        """Carga las variables de memoria"""
        if self.return_messages:
            return {self.memory_key: self.chat_memory}
        
        return {self.memory_key: [msg.content for msg in self.chat_memory]}

    def clear(self) -> None:
        """Limpia la memoria"""
        self.chat_memory = []

    def search_similar_interactions(self, query: str, k: int = 3) -> List[str]:
        """Busca interacciones similares en el historial"""
        results = self.vector_store.search_similar(query, k=k)
        # Solo devolver el texto de los resultados más relevantes
        return [text for text, _ in results]

def get_reservation_info(reservation_id):
    """Obtiene información detallada de una reserva"""
    conn = get_db_connection()
    if not conn:
        return "Error: No se pudo conectar a la base de datos"
        
    try:
        cursor = conn.cursor(dictionary=True)
        
        # Consulta principal de la reserva
        cursor.execute("""
            SELECT 
                r.id,
                r.check_in,
                r.check_out,
                r.num_guests,
                r.status,
                r.provider_reservation_id
            FROM reservation r
            WHERE r.provider_reservation_id = %s
        """, (reservation_id,))
        
        reservation = cursor.fetchone()
        if not reservation:
            return None

        # Consulta de datos extra
        cursor.execute("""
            SELECT `key`, `value`
            FROM reservation_extra_data
            WHERE reservation_id = %s
        """, (reservation['id'],))
        
        extra_data = {}
        for row in cursor.fetchall():
            extra_data[row['key']] = row['value']
        
        # Consulta de servicios adicionales (ejemplo)
        cursor.execute("""
            SELECT service_type, status
            FROM reservation_services
            WHERE reservation_id = %s
        """, (reservation['id'],))
        
        services = []
        for service in cursor.fetchall():
            services.append({
                'type': service['service_type'],
                'status': service['status']
            })
        
        # Formatear toda la información
        return {
            'id': reservation['provider_reservation_id'],
            'check_in': reservation['check_in'].isoformat() if reservation['check_in'] else None,
            'check_out': reservation['check_out'].isoformat() if reservation['check_out'] else None,
            'num_guests': reservation['num_guests'],
            'status': reservation['status'],
            'guests_registered': extra_data.get('guests_registered', '0'),
            'police_form_status': extra_data.get('police_form_status', 'pendiente'),
            'services': services,
            'extra_data': extra_data
        }
        
    except Error as e:
        print(f"Error consultando la reserva: {e}")
        return f"Error: {str(e)}"
    finally:
        cursor.close()
        conn.close()

def create_reservation_chain(vector_store: Optional[VectorStoreHandler] = None):
    """Crea una cadena de conversación avanzada con memoria de entidades y búsqueda semántica"""
    # 1. Crear el modelo
    llm = ChatOpenAI(temperature=0.7)
    
    # 2. Crear vector store si no se proporciona
    if vector_store is None:
        vector_store = VectorStoreHandler("reservation_history")
    
    # 3. Crear memoria especializada
    memory = ReservationEntityMemory(
        llm=llm,
        vector_store=vector_store,
        return_messages=True,
        memory_key="chat_history",
        k=3  # Número de entidades similares a recordar
    )
    
    # 4. Crear prompt template
    prompt = ChatPromptTemplate.from_messages([
        ("system", """Eres un asistente experto en gestión de reservas que ayuda a los huéspedes.
        
        Tienes acceso a dos fuentes de información:
        1. Base de datos de reservas: contiene la información oficial y actualizada
        2. Historial de conversaciones: te ayuda a dar contexto y mantener coherencia
        
        Reglas importantes:
        1. SIEMPRE prioriza la información de la base de datos sobre el historial
        2. Si encuentras "Información de reservas encontradas", usa esos datos como fuente principal
        3. El "Contexto de interacciones similares" es solo para referencia
        4. NUNCA inventes datos que no estén en la base de datos
        5. Si no tienes información de la base de datos, pide el número de reserva
        
        Recuerda:
        - Ser amable y profesional
        - Confirmar los detalles importantes
        - Ofrecer ayuda adicional si es necesario"""),
        MessagesPlaceholder(variable_name="chat_history"),
        ("human", "{input}")
    ])
    
    # 5. Crear la chain
    chain = prompt | llm
    
    # 6. Función para procesar mensajes
    def process_message(message: str, session_id: str = 'default') -> str:
        # Buscar IDs de reserva en el mensaje
        reservation_pattern = r'[A-Z0-9]{6,}'
        potential_ids = re.findall(reservation_pattern, message)
        
        # Obtener información de reservas si hay IDs
        reservations_info = []
        for potential_id in potential_ids:
            info = get_reservation_info(potential_id)
            if info and not isinstance(info, str):
                reservations_info.append(info)
        
        # Buscar interacciones similares
        similar_interactions = memory.search_similar_interactions(message)
        
        # Preparar el mensaje con toda la información
        message_parts = [message]
        
        # Agregar información de reservas si existe
        if reservations_info:
            message_parts.append("\nInformación de reservas encontradas:")
            for info in reservations_info:
                message_parts.append(f"""
                Reserva: {info['id']}
                Check-in: {info['check_in']}
                Check-out: {info['check_out']}
                Huéspedes: {info['guests_registered']} de {info['num_guests']}
                Estado: {info['status']}
                Formulario policía: {info['police_form_status']}
                """)
        
        # Agregar contexto de interacciones similares si existe
        if similar_interactions:
            message_parts.append("\nContexto de interacciones similares:")
            message_parts.extend(similar_interactions)
        
        # Combinar todo el contexto
        full_message = "\n".join(message_parts)
        
        # Procesar el mensaje con la chain
        response = chain.invoke({
            "input": full_message,
            "chat_history": memory.chat_memory
        })
        
        # Guardar el contexto en la memoria
        memory.save_context(
            {"input": message},
            {"output": response.content}
        )
        
        return response.content
    
    return process_message

def main():
    """Función principal para probar la chain"""
    chain = create_reservation_chain()
    
    # Ejemplo de conversación con múltiples reservas
    messages = [
        "Necesito información sobre la reserva HMS8FTTQN4",
        "¿Qué servicios adicionales tiene?",
        "También tengo otra reserva: XYZ123",
        "¿Cuál de las dos tiene más huéspedes?",
        "Para la primera reserva, ¿el formulario de policía está completo?",
    ]
    
    print("Iniciando conversación de ejemplo:")
    for message in messages:
        print(f"\nUsuario: {message}")
        response = chain(message)
        print(f"Asistente: {response}")

if __name__ == "__main__":
    main()
