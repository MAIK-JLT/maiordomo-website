from langchain_core.prompts import ChatPromptTemplate
from langchain_openai import ChatOpenAI
from langchain_core.runnables import RunnablePassthrough
from mysql.connector import Error
from db_connection import get_db_connection

def get_reservation_info(reservation_id):
    conn = get_db_connection()
    if not conn:
        return "Error: No se pudo conectar a la base de datos"
        
    try:
        cursor = conn.cursor(dictionary=True)
        cursor.execute("""
            SELECT 
                r.id,
                r.check_in,
                r.check_out,
                r.num_guests,
                r.status
            FROM reservation r
            WHERE r.provider_reservation_id = %s
        """, (reservation_id,))
        
        reservation = cursor.fetchone()
        
        if not reservation:
            return None

        cursor.execute("""
            SELECT `key`, `value`
            FROM reservation_extra_data
            WHERE reservation_id = %s
            AND `key` IN ('guests_registered', 'police_form_status')
        """, (reservation['id'],))
        
        extra_data = {}
        for row in cursor.fetchall():
            extra_data[row['key']] = row['value']
        
        # Formatear la información para el prompt
        return f"""
        Check-in: {reservation['check_in']}
        Check-out: {reservation['check_out']}
        Huéspedes totales: {reservation['num_guests']}
        Estado de la reserva: {reservation['status']}
        Huéspedes registrados: {extra_data.get('guests_registered', '0')} de {reservation['num_guests']}
        Formulario policía: {extra_data.get('police_form_status', 'pendiente')}
        """
        
    except Error as e:
        print(f"Error consultando la reserva: {e}")
        return f"Error: {str(e)}"
    finally:
        cursor.close()
        conn.close()

def create_reservation_chain():
    # 1. Crear un modelo
    llm = ChatOpenAI()
    
    # 2. Crear un prompt template
    prompt = ChatPromptTemplate.from_messages([
        ("system", """Eres un asistente que ayuda a consultar información de reservas.
        Cuando te den un número de reserva, muestra un resumen amigable de la información.
        
        Ejemplo de respuesta:
        "La reserva HMS8FTTQN4 tiene check-in el 23 de noviembre a las 16:00 y check-out
        el 28 de noviembre a las 11:00. Hay 5 huéspedes registrados."
        """),
        ("human", "Aquí está la información de la reserva: {Informacion}\nNúmero de reserva: {Reserva}")
    ])
    
    # 3. Crear la chain con el paso de obtener información
    get_info = RunnablePassthrough.assign(
        Informacion=lambda x: get_reservation_info(x["Reserva"]) or "Reserva no encontrada"
    )
    
    # 4. Retornar la chain completa
    return get_info | prompt | llm

def main():
    # Crear la chain
    chain = create_reservation_chain()
    
    # IDs de reserva reales del dump de la base de datos
    reservation_ids = ["HMS8FTTQN4", "INVALID_ID"]
    
    # Probar con diferentes IDs
    for reservation_id in reservation_ids:
        print(f"\nConsultando reserva: {reservation_id}")
        
        # Procesar la reserva
        response = chain.invoke({"Reserva": reservation_id})
        print(f"Respuesta: {response.content}")

if __name__ == "__main__":
    main()
